import React from "react";
import "./common.css"

const Footer = () => (//&#169; copyright symbol
  <div className="footer">
    <span>&#169;</span><bold>TweetApp By Kishan Gupta,2022.All rights Reserved.</bold>
  </div>
);

export default Footer;